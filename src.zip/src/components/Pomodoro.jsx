import { useState, useEffect, useRef } from "react";
import CustomizeSetting from "./com-pomo/CustomizeSettion";
function Pomodoro() {
   const [isRunning, setRunning] = useState(false);
  const [second, setSecond] = useState(1800);
  const [selectMode, setSelectMode] = useState ("pomodoro");
  // const [isSetting, setSetting] = useState(false);
  // const [settingMode, setSettingMode] = useState("General");
  const id = useRef(null); // Use null for initial ref
  const modes = [
    { name: "pomodoro", time: 1800 },
    { name: "short break", time: 300 },
    { name: "long break", time: 600 },
  ];
  const choice = [
    { option: "start"}, {option: "reset"}
  ];
  const setting = [
    {name: "General"} , { name: "Timer"}
  ];
  const fullScreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
  }
  useEffect(() => {
    if (isRunning) {
      //  setInterval(callback, delay)
      id.current = setInterval(() => {
        setSecond((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
      return () => clearInterval(id.current);
    }
  }, [isRunning]);

  function start() {
    setRunning(true);
  }
  function stop() {
    setRunning(false);
  }
  function reset() {
    setRunning(false);
    setSecond(modes.find((mode) => mode.name === selectMode)?.time || 1800); // Back to original time
  }

  function displayTime() {
    // Correct Math Logic
    const h = Math.floor(second / 3600);
    const m = Math.floor((second % 3600) / 60);
    const s = second % 60;

    const hours = String(h).padStart(2, "0");
    const mins = String(m).padStart(2, "0");
    const seconds = String(s).padStart(2, "0");

    return `${hours} : ${mins} : ${seconds}`;
  }
  return (
    <>
    <div className = {`bg-[url('./src/assets/countryside.jpg')] bg-cover h-screen  flex flex-col justify-center items-center gap-20 z-0 `} alt = "background" >
      <div className = "flex flex-col justify-center items-center gap-5 w-4/5 " >
        <div className = "flex justify-center items-center gap-8 w-full h-auto   " >
          {modes.map((mode, index) => (
            <button key = {index} className = { ` text-4xl border rounded-full bg-transparent mt-7  border-black hover:text-black hover:bg-white cursor-pointer
               ${ selectMode === mode.name ? "bg-white text-black" : "bg-green "}`} 
              onClick = { () => {
              setSelectMode( mode.name);
              setSecond(mode.time);
              }} >
            {mode.name}  
          </button>
          ))}
        </div>
          <h1 className = "text-6xl font-bold text-white"> {displayTime()} </h1>
        <div className="flex flex-row justify-center items-center gap-15  ">
          {choice.map((option, index) => (
            <button key = {index} className = {` px-6 py-5 text-3xl  border rounded-full border-black 
               cursor-pointer ${option.option === "start" ? " hover:bg-transparent bg-white text-black hover:text-white " : "bg-green" } ${option.option === "reset" ? "hover:bg-red-500 hover:text-white": "bg-black"}`} 
               onClick = { (e) => {
                if ( e.target.innerText === "start") {
                  start();
                } else if ( e.target.innerText === "pause"){
                  stop(); }
                  else {
                    reset()
                  }
              }} > { option.option === "start" ? (isRunning ? "pause" : "start") : option.option}
                        
          </button> ))}

          <i className="fa-solid fa-gear text-4xl mt-2.5 cursor-pointer"></i>
          {/* { isSetting && <CustomizeSetting /> } */}
        </div>
      </div>

        <div className= "mt-auto flex justify-center item-center gap-10 mb-5 p-5">
          <div className = "bg-black"> hello this is for api song</div>

    <i className="fa-solid fa-expand text-3xl  mt-2.5 cursor-pointer ml-auto" id = "fullscreen" onClick={fullScreen} ></i>
        </div>
    </div>


    {/* <div className = "fixed left-0 top-0 min-h-4/5 bg-black/50  z-10 flex justify-center items-center w-full  text-white  round-2xl gap-2 p-2   ">  */}
      {/* <div className = "bg-black w-1/2 h-1/2 rounded-2xl flex flex-col justify-center items-center gap-2  ">  */}
    {/* header */}
      {/* <button className = "ml-auto px-4 py-2 text-xl cursor-pointer hover:bg-white/50 hover:round-2xl">X</button> */}
      {/* body */}
      {/* <div className = "flex justify-center items-center gap-3 p-1 w-full "> */}
        {/* sidebar */}
          {/* <div className = "flex flex-col justify-center items-center gap-5  "> */}
            {/* {setting.map((option, index) => ( */}
              {/* <button key = { index } className = "px-5  py-3 cursor-pointer hover:border-b  " > */}
               {/* {option.name} </button> */}
          
            {/* ))} */}
          {/* </div> */}
          {/* customize setting */}
          {/* <div id = "contain" className = "flex-wrap justify-center items-center gap-5 p-4 mr-auto w-1/2 "> */}
            {/* <CustomizeSetting />  */}
          {/* </div> */}
      {/* </div> */}
      {/* button choice */}
      {/* <div></div>
      
      </div> */}
      
    {/* </div> */}
   
    </>
  );
}
export default Pomodoro;
