
import { useState } from "react";
function CustomizeSetting() {
    const [isOpen, setOpen] = useState(false);
    const [selected, setSelected] = useState("hi");
    const pictures = [
        { name: "hi" }, { name: "hello"}, {name : "a"}, { name: "b"}, { name: "c"}, { name: "d"}
        
    ];
    return (
        
        <>
        <div className = "flex flex-col justify-center items-center gap-5">
        <span>Select Theme</span>
        <div className = "border border-gray-300 p-2 cursor-pointer" onClick={() => {setOpen(!isOpen); console.log(isOpen)}}>
            <span>{selected}</span>
            <span><i className="fa-solid fa-caret-up rotate-180"></i></span>
            { isOpen && 
            <ul >
                {pictures.map((option, index) => (
                    <li key = {index} className = "p-2 hover:bg-gray-200" onClick={() => {

                        setSelected(option.name);
                        setOpen(false);
                        
                    }}>
                        {option.name}
                    </li>
                ))}
                </ul>}
        </div>


        </div>

        </>
    )
}
export default CustomizeSetting;